#ifndef URQMD_READ_H
#define URQMD_READ_H
#include<iostream>
#include<string>
#include<sstream>
#include<fstream>
using namespace std;

double *urqmd_qgp_function(string urqmd_path);


#endif

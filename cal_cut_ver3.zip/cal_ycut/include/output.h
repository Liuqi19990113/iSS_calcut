#ifndef OUTPUT_H
#define OUTPUT_H
#include<iostream>
#include<string>
#include<sstream>
#include<fstream>
#include<cmath>
#include<vector>
#include<iomanip>
using namespace std;

void output_function(string ycut_path, string oscar_path, string output_path);



#endif